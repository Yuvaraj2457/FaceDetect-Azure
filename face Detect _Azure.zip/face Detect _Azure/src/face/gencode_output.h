#include "kpu.h"
kpu_task_t* kpu_task_gencode_output_init(kpu_task_t* task);
